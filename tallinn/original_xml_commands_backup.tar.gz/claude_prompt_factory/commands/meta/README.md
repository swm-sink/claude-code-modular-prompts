# Meta Commands

This category contains commands for improving the Prompt Factory itself.

## Commands

*   `/meta improve`: Suggests improvements to a command or component. 