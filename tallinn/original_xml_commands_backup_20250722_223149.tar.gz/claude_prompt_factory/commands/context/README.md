# Context Commands

This category contains commands for priming Claude's understanding of the codebase.

## Commands

*   `/context prime`: Performs a standard analysis of the codebase.
*   `/context prime-mega`: Performs a deep, multi-agent analysis of the codebase. 